import java.util.Stack;

public class Main {
  
    public static boolean checkDelimiters(String s) 
  {
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < s.length(); i++) 
        {
            char currentChar = s.charAt(i);

            if (currentChar == '(')
            {
                stack.push(currentChar);
            } 
            else if (currentChar == ')') 
            {
                if (stack.isEmpty() || stack.pop() != '(') 
                {
                    return false; 
                }
            }
        }

        return stack.isEmpty();
    }

    public static void main(String[] args) 
  {
      
        String text = "(())";
        boolean isBalanced = checkDelimiters(text);
        System.out.println("Text: (())");
        System.out.println("Is it balanced: " + isBalanced);

        text = "(()";
        isBalanced = checkDelimiters(text);
        System.out.println("Text: (()");
        System.out.println("Is it balanced: " + isBalanced);
    }
}

